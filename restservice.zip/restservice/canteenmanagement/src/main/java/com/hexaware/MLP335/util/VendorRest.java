package com.hexaware.MLP335.util;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;
import com.hexaware.MLP335.model.Vendor;
import com.hexaware.MLP335.factory.VendorFactory;

/**
 * This class provides a REST interface for the employee entity.
 */
@Path("/Vendor")
public class VendorRest {
  /**
   * Returns Vendor details.
   * 
   * @return the Vendor details
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public final Vendor[] listVendors() {
    final Vendor[] vendor = VendorFactory.showVendor();
    return vendor;
  }

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/seek/{VEN_ID}")
  public final Vendor listVendor(@PathParam("VEN_ID") int VEN_ID) {
    final Vendor vendor = VendorFactory.showVendors(VEN_ID);
    return vendor;
  }

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/query")
  public final Vendor listVendorQuery(@QueryParam("VEN_ID") int VEN_ID) {
    final Vendor vendor = VendorFactory.showVendors(VEN_ID);
    return vendor;
  }

  @POST
  @Path("/insert")
  @Produces("text/plain")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  public final String insertVendor(@FormParam("VEN_ID")int VEN_ID,
                                     @FormParam("VEN_NAME")String VEN_NAME,
                                     @FormParam("CUS_ID")int CUS_ID
  ){
    
   VendorFactory.insertVendor(VEN_ID,VEN_NAME,CUS_ID);

   return "Record inserted successfully";
  }

  @PUT
  @Path("/update")
  @Produces("text/plain")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  public final String updateVendor(@FormParam("VEN_ID")int VEN_ID,
                                     @FormParam("VEN_NAME")String VEN_NAME,
                                     @FormParam("CUS_ID")int CUS_ID
  ){
    VendorFactory.updateVendor(VEN_ID,VEN_NAME,CUS_ID);


   return "Record updated successfully";
  }

  @DELETE
  @Path("/delete")
  @Produces("text/plain")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  public final String deleteVendor(@FormParam("VEN_ID")int VEN_ID){
    
   VendorFactory.deleteVendor(VEN_ID);

   return "Record deleted successfully";
  }  
}