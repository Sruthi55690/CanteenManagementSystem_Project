package com.hexaware.MLP335.util;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;
import com.hexaware.MLP335.model.Customer;
import com.hexaware.MLP335.factory.CustomerFactory;

/**
 * This class provides a REST interface for the employee entity.
 */
@Path("/customer")
public class CustomerRest {
  /**
   * Returns Menu details.
   * 
   * @return the menu details
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public final Customer[] listCustomers() {
    final Customer[] customer = CustomerFactory.showCustomer();
    return customer;
  }

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/seek/{CUS_ID}")
  public final Customer listCustomer(@PathParam("CUS_ID") int CUS_ID) {
    final Customer customer =CustomerFactory.showCustomers(CUS_ID);
    return customer;
  }

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/query")
  public final Customer listCustomerQuery(@QueryParam("CUS_ID") int CUS_ID) {
    final Customer customer = CustomerFactory.showCustomers(CUS_ID);
    return customer;
  }

  @POST
  @Path("/insert")
  @Produces("text/plain")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  public final String insertCustomer(@FormParam("CUS_ID")int CUS_ID,
                                     @FormParam("CUS_NAME")String CUS_NAME,
                                     @FormParam("CUS_EMAIL")String CUS_EMAIL,
                                     @FormParam("CUS_PHN")int CUS_PHN,
                                     @FormParam("CUS_ADD")String CUS_ADD
  ){
    
   CustomerFactory.insertCustomer(CUS_ID,CUS_NAME,CUS_EMAIL,CUS_PHN,CUS_ADD);

   return "Record inserted successfully";
  }

  @PUT
  @Path("/update")
  @Produces("text/plain")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  public final String updateMenu(@FormParam("CUS_ID")int CUS_ID,
                                             @FormParam("CUS_NAME")String CUS_NAME,
                                             @FormParam("CUS_EMAIL")String CUS_EMAIL,
                                            @FormParam("CUS_PHN")int CUS_PHN,
                                            @FormParam("CUS_ADD")String CUS_ADD
  ){
    CustomerFactory.updateCustomer(CUS_ID,CUS_NAME,CUS_EMAIL,CUS_PHN,CUS_ADD);


   return "Record updated successfully";
  }

  @DELETE
  @Path("/delete")
  @Produces("text/plain")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  public final String deleteCustomer(@FormParam("CUS_ID")int CUS_ID){
    
   CustomerFactory.deleteCustomer(CUS_ID);

   return "Record deleted successfully";
  }  
}