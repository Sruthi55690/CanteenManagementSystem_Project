package com.hexaware.MLP335.util;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;

import java.sql.Date;
import java.time.LocalDate;

import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;
import com.hexaware.MLP335.model.Orders;
import com.hexaware.MLP335.factory.OrdersFactory;

/**
 * This class provides a REST interface for the employee entity.
 */
@Path("/Orders")
public class OrdersRest {
  /**
   * Returns Orders details.
   * 
   * @return the Orders details
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public final Orders[] listOrderss() {
    final Orders[] orders = OrdersFactory.showOrders();
    return orders;
  }

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/seek/{ORD_ID}")
  public final Orders listOrders(@PathParam("ORD_ID") int ORD_ID) {
    final Orders orders = OrdersFactory.showOrderss(ORD_ID);
    return orders;
  }

  @GET
  @Produces(MediaType.APPLICATION_JSON)
  @Path("/query")
  public final Orders listOrdersQuery(@QueryParam("ORD_ID") int ORD_ID) {
    final Orders orders = OrdersFactory.showOrderss(ORD_ID);
    return orders;
  }

  @POST
  @Path("/insert")
  @Produces("text/plain")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  public final String insertOrders(@FormParam("ORD_ID")int ORD_ID,
                                  @FormParam("ORD_DATE")LocalDate ORD_DATE,
                                  @FormParam("FOOD_ID")int FOOD_ID,
                                  @FormParam("CUS_ID")int CUS_ID,
                                  @FormParam("PRICE")float PRICE
  ){
    
   OrdersFactory.insertOrders(ORD_ID,ORD_DATE,FOOD_ID,CUS_ID,PRICE);

   return "Record inserted successfully";
  }

  @PUT
  @Path("/update")
  @Produces("text/plain")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  public final String updateOrders(@FormParam("ORD_ID")int ORD_ID,
                                   @FormParam("ORD_DATE")LocalDate ORD_DATE,
                                   @FormParam("FOOD_ID")int FOOD_ID,
                                   @FormParam("CUS_ID")int CUS_ID,
                                   @FormParam("PRICE")float PRICE
  ){
    OrdersFactory.updateOrders(ORD_ID,ORD_DATE,FOOD_ID,CUS_ID,PRICE);

   return "Record updated successfully";
  }

  @DELETE
  @Path("/delete")
  @Produces("text/plain")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  public final String deleteOrders(@FormParam("ORD_ID")int ORD_ID){
    
   OrdersFactory.deleteOrders(ORD_ID);

   return "Record deleted successfully";
  }  
}