package com.hexaware.MLP335.model;
import java.util.Objects;

public class Vendor {
    private int VEN_ID;
    private String VEN_NAME;
    private int CUS_ID;

    public Vendor(){

    }

    public Vendor(int VEN_ID){
        this.VEN_ID = VEN_ID;
    }

    public Vendor(int VEN_ID, String VEN_NAME, int CUS_ID){
        this.VEN_ID = VEN_ID;
        this.VEN_NAME = VEN_NAME;
        this.CUS_ID = CUS_ID;
    }

    public int getVEN_ID(){
        return this.VEN_ID;
    }

    public void setVEN_ID(int VEN_ID){
        this.VEN_ID = VEN_ID;
    }

    public String getVEN_NAME(){
        return this.VEN_NAME;
    }

    public void setVEN_NAME(String VEN_NAME){
        this.VEN_NAME = VEN_NAME;
    }

    public int getCUS_ID(){
        return this.CUS_ID;
    }

    public void setCUS_ID(int CUS_ID){
        this.CUS_ID = CUS_ID;
    }
    @Override
    public int hashCode() {
      return VEN_ID;
    }

    @Override
    public boolean equals(Object another){
        boolean isItSame = false;
        Vendor vendor = null;
        if(another != null){
        if(this.getClass() == another.getClass()){
            vendor = (Vendor)another;

                if(this.VEN_ID==(vendor.VEN_ID) &&
                 this.VEN_NAME.equals(vendor.VEN_NAME) &&this.CUS_ID==(vendor.CUS_ID)) {
                     isItSame = true;
                 }
            }
        }

        return isItSame;
    }

    public String toString(){
        return "\nVEN_ID: " + this.VEN_ID + "\n" +
                "VEN_NAME: " + this.VEN_NAME + "\n" +
                "CUS_ID: " + this.CUS_ID + "\n" +
                "===============================================";
    }
}