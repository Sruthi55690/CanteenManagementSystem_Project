package com.hexaware.MLP335.factory;

import com.hexaware.MLP335.persistence.OrdersDAO;
import com.hexaware.MLP335.persistence.DbConnection;
import java.util.List;
import java.time.LocalDate;

import com.hexaware.MLP335.model.Orders;
/**
 * MenuFactory class used to fetch menu data from database.
 * @author hexware
 */
public class OrdersFactory {
  /**
   *  Protected constructor.
   */
  protected OrdersFactory() {

  }
  /**
   * Call the data base connection.
   * @return the connection object.
   */
  private static OrdersDAO dao() {
    DbConnection db = new DbConnection();
    return db.getConnect().onDemand(OrdersDAO.class);
  }
  /**
   * Call the data base connection.
   * @return the array of menu object.
   */
  public static Orders[] showOrders() {
    List<Orders> Orders = dao().show();
    return Orders.toArray(new Orders[Orders.size()]);
  }

  public static Orders showOrderss(int ORD_ID) {
    Orders orders = dao().showspecific(ORD_ID);
    return orders;
  }

  public static void insertOrders(int ORD_ID, LocalDate ORD_DATE,int FOOD_ID, int CUS_ID,float PRICE) {
    dao().insert(ORD_ID,ORD_DATE,FOOD_ID,CUS_ID,PRICE);
    System.out.println("Record inserted successfully.");
  }

  public static void updateOrders(int ORD_ID, LocalDate ORD_DATE, int FOOD_ID, int CUS_ID,float PRICE) {
    dao().update(ORD_ID,ORD_DATE,FOOD_ID,CUS_ID,PRICE);
    System.out.println("Record updated successfully.");
  }

    public static void deleteOrders(int ORD_ID) {
    dao().delete(ORD_ID);
    System.out.println("Record deleted successfully.");
  }
}