package com.hexaware.MLP335.model;

import org.junit.Test;
import org.junit.Ignore;

import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.After;
import static org.junit.Assert.*;

import java.util.List;

import com.hexaware.MLP335.model.Orders;

import com.hexaware.MLP335.persistence.OrdersDAO;
import com.hexaware.MLP335.persistence.DbConnection;
import java.time.LocalDate;

public class OrdersTest {
    private static DbConnection db;
    private OrdersDAO ordersDAO;

    @BeforeClass
    public static void setup(){
        db = new DbConnection();
    }

    @Ignore 
    public void testInsert(){
        ordersDAO = db.getConnect().onDemand(OrdersDAO.class);
        int preCount = 0;
        int postCount = 0;

        int ORD_ID=2;
        LocalDate ORD_DATE=LocalDate.now();
        int FOOD_ID=1;
        int  CUS_ID=16;
        float PRICE=200;
        List<Orders>orderss = ordersDAO.show();


        preCount = orderss.size();

        ordersDAO.update(ORD_ID,ORD_DATE,FOOD_ID,CUS_ID,PRICE);

        orderss = ordersDAO.show();

        postCount = orderss.size();

        assertEquals(preCount+1,postCount);
    }

    @Ignore
    public void testUpdate(){
        ordersDAO = db.getConnect().onDemand(OrdersDAO.class);
        
        int ORD_ID=1;
        LocalDate ORD_DATE=LocalDate.now();
        int FOOD_ID=1;
        int  CUS_ID=16;
        float PRICE=600;
        Orders ord1 = new Orders(ORD_ID,ORD_DATE,FOOD_ID,CUS_ID,PRICE);

        ordersDAO.update(ORD_ID,ORD_DATE,FOOD_ID,CUS_ID,PRICE);
        

        List<Orders>orderss = ordersDAO.show();
        boolean isItSame = false;
        for (Orders orders : orderss) {
            if(orders.getORD_ID() == 1){
                if(orders.equals(ord1)){
                    isItSame = true;
                    break;
                }
            }
        }
        assertTrue(isItSame);
    }

    @Ignore
    public void testDelete(){
        ordersDAO = db.getConnect().onDemand(OrdersDAO.class);
        
        int preCount = 0;
        int postCount = 0;

        List<Orders>orderss = ordersDAO.show();

        preCount = orderss.size();

        ordersDAO.delete(1);

        orderss = ordersDAO.show();

        postCount = orderss.size();

        assertEquals(preCount-1,postCount);
    }

   @AfterClass
    public static void tearDown(){
        DbConnection db = new DbConnection();
    }    
}