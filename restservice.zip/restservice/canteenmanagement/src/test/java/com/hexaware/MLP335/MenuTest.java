package com.hexaware.MLP335.model;

import org.junit.Test;
import org.junit.Ignore;

import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.After;
import static org.junit.Assert.*;

import java.util.List;

import com.hexaware.MLP335.model.Menu;

import com.hexaware.MLP335.persistence.MenuDAO;
import com.hexaware.MLP335.persistence.DbConnection;

public class MenuTest {
    private static DbConnection db;
    private MenuDAO menuDAO;

    @BeforeClass
    public static void setup(){
        db = new DbConnection();
    }

    @Ignore  
    public void testInsert(){
        menuDAO = db.getConnect().onDemand(MenuDAO.class);
        int preCount = 0;
        int postCount = 0;

        int FOOD_ID= 7;
        String ITEM_NAME= "IDLY2255";
        float FOOD_PRICE=200;
        List<Menu>menus = menuDAO.show();

        preCount = menus.size();

        menuDAO.insert(FOOD_ID,ITEM_NAME,FOOD_PRICE);

        menus = menuDAO.show();

        postCount = menus.size();

        assertEquals(preCount+1,postCount);
    }

    @Ignore
    public void testUpdate(){
        menuDAO = db.getConnect().onDemand(MenuDAO.class);
        
        int FOOD_ID= 7;
        String ITEM_NAME= "puri";
        float FOOD_PRICE=100;
        Menu men = new Menu(FOOD_ID,ITEM_NAME,FOOD_PRICE);

        menuDAO.update(FOOD_ID,ITEM_NAME,FOOD_PRICE);
        

        List<Menu>menus = menuDAO.show();
        boolean isItSame = false;
        for (Menu menu : menus) {
            if(menu.getFOOD_ID() == 1){
                if(menu.equals(men)){
                    isItSame = true;
                    break;
                }
            }
        }
        assertTrue(isItSame);
    }

    @Ignore 
    public void testDelete(){
        menuDAO = db.getConnect().onDemand(MenuDAO.class);
        int preCount = 0;
        int postCount = 0;

        List<Menu>menus = menuDAO.show();

        preCount = menus.size();

        menuDAO.delete(6);

        menus = menuDAO.show();

        postCount = menus.size();

        assertEquals(preCount-1,postCount);
    }

   @AfterClass
    public static void tearDown(){
        DbConnection db = new DbConnection();
    }    
}