package com.hexaware.MLP335.model;

import org.junit.Test;
import org.junit.Ignore;

import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.After;
import static org.junit.Assert.*;

import java.util.List;

import com.hexaware.MLP335.model.Vendor;

import com.hexaware.MLP335.persistence.VendorDAO;
import com.hexaware.MLP335.persistence.DbConnection;

public class VendorTest {
    private static DbConnection db;
    private VendorDAO vendorDAO;

    @BeforeClass
    public static void setup(){
        db = new DbConnection();
    }

    @Ignore 
    public void testInsert(){
        vendorDAO = db.getConnect().onDemand(VendorDAO.class);
        int preCount = 0;
        int postCount = 0;

        int VEN_ID=1;
        String VEN_NAME="abc";
        int CUS_ID=16;
        List<Vendor>vendors = vendorDAO.show();

        preCount = vendors.size();

        vendorDAO.insert(VEN_ID,VEN_NAME,CUS_ID);

        vendors = vendorDAO.show();

        postCount = vendors.size();

        assertEquals(preCount+1,postCount);
    }

    @Ignore
    public void testUpdate(){
        vendorDAO = db.getConnect().onDemand(VendorDAO.class);
        
        int VEN_ID=1;
        String VEN_NAME="";
        int CUS_ID=16;
        Vendor ven = new Vendor(VEN_ID,VEN_NAME,CUS_ID);
        vendorDAO.insert(VEN_ID,VEN_NAME,CUS_ID);
        

        List<Vendor>vendors = vendorDAO.show();
        boolean isItSame = false;
        for (Vendor vendor : vendors) {
            if(vendor.getVEN_ID() == 1){
                if(vendor.equals(ven)){
                    isItSame = true;
                    break;
                }
            }
        }
        assertTrue(isItSame);
    }

    @Ignore
    public void testDelete(){
        vendorDAO = db.getConnect().onDemand(VendorDAO.class);
        int preCount = 0;
        int postCount = 0;

        List<Vendor>vendors = vendorDAO.show();

        preCount =vendors.size();

        vendorDAO.delete(1);

        vendors = vendorDAO.show();

        postCount = vendors.size();

        assertEquals(preCount-1,postCount);
    }

   @AfterClass
    public static void tearDown(){
        DbConnection db = new DbConnection();
    }    
}