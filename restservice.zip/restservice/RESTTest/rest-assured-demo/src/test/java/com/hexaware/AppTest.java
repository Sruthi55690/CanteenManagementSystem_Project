package com.hexaware;

/*import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;*/
/*import io.restassured.RestAssured.*;
import io.restassured.matcher.RestAssuredMatchers.*;
import org.hamcrest.Matchers.*;*/

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import java.time.LocalDate;
import static com.jayway.restassured.RestAssured.*;

import org.junit.Test;
import org.junit.Ignore;
import static org.junit.Assert.*;
/**
 * Unit test for simple App.
 */
public class AppTest {
    /**
     * Rigorous Test.
     */

@Ignore
public void testInsertMenu() {
    Response response = given()
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("FOOD_ID", "11")
    .formParam("ITEM_NAME", "CAKE")
    .formParam("FOOD_PRICE", "99.99f")
    .request()
    .post("http://localhost:8080/MLP335/api/menu/insert");

    String message = response.getBody().asString();
 
    assertNotNull(message);
}

@Ignore
public void testUpdateMenu() {
    Response response = given()
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("FOOD_ID", "1")
    .formParam("ITEM_NAME", "IDLY111")
    .formParam("FOOD_PRICE", "100.00f")
    .request()
    .put("http://localhost:8080/MLP335/api/menu/update");

    String message = response.getBody().asString();
 
    assertNotNull(message);
}

@Ignore
public void testDeleteMenu() {
    Response response = given()
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("FOOD_ID", "5")
    .request()
    .delete("http://localhost:8080/MLP335/api/menu/delete");

    String message = response.getBody().asString();
 
    assertNotNull(message);
}

@Ignore
public void testListMenus() {
    Response response = given()
    .request()
    .get("http://localhost:8080/MLP335/api/menu");

    String message = response.getBody().asString();
    System.out.println(message);
    assertNotNull(message);
}

@Ignore
public void testListMenu() {
    Response response = given()
    .request()
    .get("http://localhost:8080/MLP335/api/menu/seek/13");

    String message = response.getBody().asString();
    System.out.println(message);
    assertNotNull(message);
}

@Ignore
public void testListMenuQuery() {
    Response response = given()
    .queryParam("FOOD_ID","4")
    .request()
    .get("http://localhost:8080/MLP335/api/menu/query");

    String message = response.getBody().asString();
    System.out.println(message);
    assertNotNull(message);
}








@Ignore
public void testInsertCustomer() {
    Response response = given()
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("CUS_ID", "11")
    .formParam("CUS_NAME", "zack")
    .formParam("CUS_EMAIL", "zack@gmail.com")
    .formParam("CUS_PHN", "456")
    .formParam("CUS_ADD", "US")
    .request()
    .post("http://localhost:8080/MLP335/api/customer/insert");

    String message = response.getBody().asString();
 
    assertNotNull(message);
}

@Ignore
public void testUpdateCustomer() {
    Response response = given()
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("CUS_ID", "12")
    .formParam("CUS_NAME", "zames")
    .formParam("CUS_EMAIL", "zames@gmail.com")
    .formParam("CUS_PHN", "421")
    .formParam("CUS_ADD", "UK")
    .request()
    .put("http://localhost:8080/MLP335/api/customer/update");

    String message = response.getBody().asString();
 
    assertNotNull(message);
}

@Ignore
public void testDeleteCustomer() {
    Response response = given()
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("CUS_ID", "2")
    .request()
    .delete("http://localhost:8080/MLP335/api/customer/delete");

    String message = response.getBody().asString();
 
    assertNotNull(message);
}

@Ignore
public void testListCustomers() {
    Response response = given()
    .request()
    .get("http://localhost:8080/MLP335/api/customer");

    String message = response.getBody().asString();
    System.out.println(message);
    assertNotNull(message);
}

@Ignore
public void testListCustomer() {
    Response response = given()
    .request()
    .get("http://localhost:8080/MLP335/api/customer/seek/13");

    String message = response.getBody().asString();
    System.out.println(message);
    assertNotNull(message);
}

@Ignore
public void testListCustomerQuery() {
    Response response = given()
    .queryParam("CUS_ID","12")
    .request()
    .get("http://localhost:8080/MLP335/api/customer/query");

    String message = response.getBody().asString();
    System.out.println(message);
    assertNotNull(message);
}








@Ignore
public void testInsertVendor() {
    Response response = given()
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("VEN_ID", "3")
    .formParam("VEN_NAME", "PQRS")
    .formParam("CUS_ID", "13")
    .request()
    .post("http://localhost:8080/MLP335/api/vendor/insert");

    String message = response.getBody().asString();
 
    assertNotNull(message);
}

@Ignore
public void testUpdateVendor() {
    Response response = given()
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("VEN_ID", "2")
    .formParam("VEN_NAME", "MNOP")
    .formParam("CUS_ID", "2")
    .request()
    .put("http://localhost:8080/MLP335/api/vendor/update");

    String message = response.getBody().asString();
 
    assertNotNull(message);
}

@Ignore
public void testDeleteVendor() {
    Response response = given()
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("VEN_ID", "3")
    .request()
    .delete("http://localhost:8080/MLP335/api/vendor/delete");

    String message = response.getBody().asString();
 
    assertNotNull(message);
}

@Ignore
public void testListVendors() {
    Response response = given()
    .request()
    .get("http://localhost:8080/MLP335/api/vendor");

    String message = response.getBody().asString();
    System.out.println(message);
    assertNotNull(message);
}

@Ignore
public void testListVendor() {
    Response response = given()
    .request()
    .get("http://localhost:8080/MLP335/api/vendor/seek/13");

    String message = response.getBody().asString();
    System.out.println(message);
    assertNotNull(message);
}

@Ignore
public void testListVendorQuery() {
    Response response = given()
    .queryParam("VEN_ID","2")
    .request()
    .get("http://localhost:8080/MLP335/api/vendor/query");

    String message = response.getBody().asString();
    System.out.println(message);
    assertNotNull(message);
}







@Ignore
public void testInsertOrders() {

    Response response = given()
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("ORD_ID", "4")
    .formParam("ORD_DATE", "LocalDate.now()")
    .formParam("FOOD_ID", "4")
    .formParam("CUS_ID", "4")
    .formParam("PRICE", "99.99f")
    .request()
    .post("http://localhost:8080/MLP335/api/orders/insert");

    String message = response.getBody().asString();
 
    assertNotNull(message);
}

@Ignore
public void testUpdateOrders() {
    Response response = given()
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("ORD_ID", "3")
    .formParam("ORD_DATE", "today")
    .formParam("FOOD_ID", "3")
    .formParam("CUS_ID", "11")
    .formParam("PRICE", "99.99f")
    .request()
    .put("http://localhost:8080/MLP335/api/orders/update");

    String message = response.getBody().asString();
 
    assertNotNull(message);
}

@Ignore
public void testDeleteOrders() {
    Response response = given()
    .header("Content-Type", "application/x-www-form-urlencoded")
    .formParam("ORD_ID", "1")
    .request()
    .delete("http://localhost:8080/MLP335/api/orders/delete");

    String message = response.getBody().asString();
 
    assertNotNull(message);
}

@Test
public void testListOrderss() {
    Response response = given()
    .request()
    .get("http://localhost:8080/MLP335/api/orders");

    String message = response.getBody().asString();
    System.out.println(message);
    assertNotNull(message);
}

@Ignore
public void testListOrders() {
    Response response = given()
    .request()
    .get("http://localhost:8080/MLP335/api/orders/seek/13");

    String message = response.getBody().asString();
    System.out.println(message);
    assertNotNull(message);
}

@Ignore
public void testListOrdersQuery() {
    Response response = given()
    .queryParam("ORD_ID","2")
    .request()
    .get("http://localhost:8080/MLP335/api/orders/query");

    String message = response.getBody().asString();
    System.out.println(message);
    assertNotNull(message);
}
}